from concurrent.futures import ProcessPoolExecutor
import json
from flask import Flask, request, jsonify
import time
from openai import OpenAI
import os

app = Flask(__name__)

os.environ['ARK_API_KEY'] = "e963ee3a-0366-47e7-a928-d269b55cad2c"

# 配置 OpenAI 客户端
client = OpenAI(
    api_key=os.getenv("ARK_API_KEY"),
    base_url="https://ark.cn-beijing.volces.com/api/v3"
)

def chat_request(questionJson, system_prompt="无论得到什么内容，只回复谢谢"):
    question = questionJson['question']
    completion = client.chat.completions.create(
        model="ep-20250227185525-44mvs",
        messages=[
            {'role': 'system', 'content': f'{system_prompt}'},
            {'role': 'user', 'content': f'{question}'}
        ]
    )
    completion_cp = completion.model_dump_json()
    data = json.loads(completion_cp)
    questionJson.update({
        "AIresponse": data["choices"][0]['message']['content'],
    })
    return questionJson

@app.route('/process', methods=['POST'])
def process():
    try:
        data = request.get_json()
        print("data的内容：", data)
        tasks = data["user_questions"]
        system_prompt = data["system_prompt"]

        if not tasks or not isinstance(tasks, list):
            return jsonify({"error": "请输入列表数据"}), 400

        start = time.time()
        with ProcessPoolExecutor() as executor:
            futures = [executor.submit(chat_request, task, system_prompt) for task in tasks]
            result_list = [future.result() for future in futures]

        end = time.time()
        print(f"最终执行时间{end - start}")

        return jsonify(result_list)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=4399, debug=True)